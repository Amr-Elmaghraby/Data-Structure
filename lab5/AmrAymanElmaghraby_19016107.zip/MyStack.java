import java.util.Scanner;

interface ILinkedList {

    public void add(int index, Object element);

    public void add(Object element);

    public Object get(int index);


    public void set(int index, Object element);

    public void clear();

    public boolean isEmpty();

    public void remove(int index);

    public int size();

    public ILinkedList sublist(int fromIndex, int toIndex);

    public boolean contains(Object o);

    public void printList(ILinkedList list);

}
class Node{
    private int element;
    private Node next;
    Node(int element){
        this.element=element;
        this.next=null;
    }
    public int getElement(){
        return element;
    }

    public void setElement(int element) {
        this.element = element;
    }

    public Node getNext() {
        return next;
    }

    public void setNext(Node next) {
        this.next = next;
    }
}


 class SingleLinkedList implements ILinkedList {
    static boolean error=false;
    private Node head;
    private Node tail;
    private int size;
    public SingleLinkedList(){
        head=null;
        this.tail=null;
        size=0;
    }

    @Override
    public void add(int index, Object element) {
        if( ( (index>=size) && (size!=0) ) || ( index<0) ){
            error=true;
            return;

        }
        if(index==0){
            Node newNode= new Node((int)element);
            newNode.setNext(head);
            head=newNode;
            size++;
        }
        else {
            Node temp = head;
            for (int i = 0; i < index - 1; i++) {
                temp = temp.getNext();
            }
            Node nextNode = temp.getNext();
            Node newNode = new Node((int) element);
            temp.setNext(newNode);
            newNode.setNext(nextNode);
            size++;
        }
    }
    // addlast
    @Override
    public void add( Object element){
        Node newNode = new Node((int)element);
        if(head==null && tail==null)
        {
            head=newNode;
            tail=newNode;
            size++;
        }
        else{
            tail.setNext(newNode);
            tail=newNode;
            size++;
        }
    }
    @Override
    public Object get(int index){
        if(index>=size || index<0) {
            error=true;
            return null;
        }

        Node temp=head;
        for (int i = 0; i <index ; i++) {
            temp=temp.getNext();
        }
        return temp.getElement();

    }
    @Override
    public void set(int index, Object element) {


         if (index >= size || index < 0) {


            error = true;
            return;
        }
        else {
            Node temp = head;
            for (int i = 0; i < index; i++) {
                temp = temp.getNext();
            }
            temp.setElement((int) element);
        }
    }
    @Override
    public void clear(){
        Node temp=head;
        Node nextNode;
        for (int i = 0; i < size; i++) {
            nextNode=temp.getNext();
            temp.setNext(null);
            temp=nextNode;

        }
        size=0;

    }
    @Override
    public boolean isEmpty(){
        return size == 0;
    }
    @Override
    public void remove(int index){
        if( index<0 || index>=size)
        {
            error=true;
            return;
        }
        Node temp = head;
        if(index==0){
          head=head.getNext();
          temp.setNext(null);
          size--;

        }
        else {


            for (int i = 0; i < index - 1; i++) {
                temp = temp.getNext();
            }
            Node nextNode = temp.getNext();
            temp.setNext(nextNode.getNext());
            nextNode.setNext(null);
            size--;

        }
    }
    @Override
    public int size(){
        return size;
    }
    @Override
    public ILinkedList sublist(int fromIndex, int toIndex){
        if(fromIndex<0 || toIndex>=size || toIndex<fromIndex )
        {
            error=true;
            return null;
        }
        ILinkedList sublist= new SingleLinkedList();
        Node temp =head;
        for (int i = 0; i < fromIndex; i++) {
            temp=temp.getNext();
        }

        for (int i =fromIndex; i <toIndex+1 ; i++) {
            sublist.add(temp.getElement());
            temp=temp.getNext();
        }
        return sublist;

    }
    @Override
    public boolean contains(Object o){
        Node temp = head;
        for (int i = 0; i < size; i++) {
            if(temp.getElement()== (int)o )return true;
            else temp=temp.getNext();

        }
        return false;
    }
    public void printList(ILinkedList list){
        System.out.print("[");
        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i));

            if(i!=list.size()-1) System.out.print(", ");

        }
        System.out.println("]");
    }
 }

interface IStack {
  
    /*** Removes the element at the top of stack and returnsthat element.
    * @return top of stack element, or through exception if empty
    */
    
    public Object pop();
    
    /*** Get the element at the top of stack without removing it from stack.
    * @return top of stack element, or through exception if empty
    */
    
    public Object peek();
    
    /*** Pushes an item onto the top of this stack.
    * @param object to insert*
    */
    
    public void push(Object element);
    
    /*** Tests if this stack is empty
    * @return true if stack empty
    */
    public boolean isEmpty();
    
    public int size();
  }
  public class MyStack implements IStack {

    static ILinkedList list = new SingleLinkedList();

    @Override
    public Object pop(){
        if(list.size()==0){
            System.out.println("Error");
            return 0;}
        list.remove(0);

        return list.get(0);
    }
    @Override
    public Object peek(){
        return list.get(0);
        
    }
    @Override
    public void push(Object element){
        list.add(0,element);
    }
    @Override
    public boolean isEmpty(){
        return list.isEmpty();
    }
    @Override
    public int size(){
        return (int)list.size();
    }


    public static void main(String[] args) {
        try{
            Scanner input = new Scanner(System.in);
            String ss = input.nextLine().replaceAll("\\[|\\]","");
            String[] ele = ss.split(", ");
            list = new SingleLinkedList();
            if(!(ele.length==1 && ele[0].isEmpty())){
                for(int i=0;i<ele.length;i++){
                    list.add(Integer.parseInt(ele[i]));
                }
            }
            IStack stack = new MyStack();
            String meth =input.nextLine();
            switch (meth){
                case "push":{
                    int value = input.nextInt();
                    stack.push(value);
                    list.printList(list);
                    break;
                }
                case"pop":{
                    stack.pop();
                    list.printList(list);
                    break;
                }
                case"peek":{
                    int peek=(int) stack.peek();
                    System.out.println(peek);
                    break;
                }
                case"isEmpty":{
                    boolean bo = stack.isEmpty();
                    if(bo==true){System.out.println("True");}
                    else
                    System.out.println("False");
                    break;
                }
                case"size":{
                    int size = stack.size();
                    System.out.println(size);
                    break;
                }
                default:{
                    System.out.println("Error");
                }
            }

        }catch(Exception e){System.out.println("Error");}
    }
  }